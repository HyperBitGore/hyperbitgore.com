Initial game screen will be blank press any key to fix that
Goal is to win 10 matches in a row to get to championship match of tournament
Win by putting your enemy's back On Mat Down
Use the different actions to do this
Grab a limb and commit any of 8 actions
As well 3 non-grab related actions
12 limbs
Some limbs when moved will move others
Some limbs can't be moved without other limbs in certain positions
3 different position metrics
	-Mat Position: On Mat, In Air
	-Space Position: Forward, Back
	-Facing: Down, Up
Can resist enemy movements with resist action
Can hold limbs in a position with hold action
Other actions are pretty self explanatory
Grabbing multiple limbs will increase your chance of success as the enemy will have too much to focus on
As well between matches you get to increase the power of your limbs
GL
HF